## Prerequisites

Install Docker Engine (Docker version 20.10.13, build a224086)

## Run the setup

```
sh node-setup.sh
```
